from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.db import transaction
from django.db.models import Q
from .models import Sale, SaleItem
from inventory.models import Product
import json

@login_required
def pos_interface(request):
    """Point of Sale interface"""
    products = Product.objects.filter(stock_quantity__gt=0).select_related('category')
    return render(request, 'sales/pos.html', {'products': products})

@login_required
def search_product(request):
    """AJAX endpoint to search products by barcode or name"""
    query = request.GET.get('q', '')
    
    if query:
        products = Product.objects.filter(
            Q(barcode__icontains=query) | Q(name__icontains=query),
            stock_quantity__gt=0
        ).values('id', 'name', 'barcode', 'sell_price', 'stock_quantity')[:10]
        
        return JsonResponse(list(products), safe=False)
    
    return JsonResponse([], safe=False)

@login_required
@transaction.atomic
def process_sale(request):
    """Process a sale transaction"""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            items = data.get('items', [])
            payment_method = data.get('payment_method', 'cash')
            
            if not items:
                return JsonResponse({'success': False, 'error': 'No items in cart'})
            
            # Create sale
            sale = Sale.objects.create(
                cashier=request.user,
                payment_method=payment_method,
                total_amount=0
            )
            
            total = 0
            
            # Create sale items and update stock
            for item in items:
                product = Product.objects.get(id=item['product_id'])
                quantity = int(item['quantity'])
                
                if product.stock_quantity < quantity:
                    sale.delete()
                    return JsonResponse({
                        'success': False,
                        'error': f'Insufficient stock for {product.name}'
                    })
                
                # Create sale item
                SaleItem.objects.create(
                    sale=sale,
                    product=product,
                    quantity=quantity,
                    price_at_sale=product.sell_price,
                    subtotal=quantity * product.sell_price
                )
                
                # Update stock
                product.stock_quantity -= quantity
                product.save()
                
                total += quantity * product.sell_price
            
            # Update sale total
            sale.total_amount = total
            sale.save()
            
            return JsonResponse({
                'success': True,
                'sale_id': sale.id,
                'total': float(total)
            })
            
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@login_required
def sales_list(request):
    """List all sales"""
    sales = Sale.objects.select_related('cashier').prefetch_related('items__product').order_by('-timestamp')
    
    # Calculate statistics
    from django.db.models import Sum, Avg
    total_revenue = sales.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    average_sale = sales.aggregate(Avg('total_amount'))['total_amount__avg'] or 0
    
    context = {
        'sales': sales,
        'total_revenue': total_revenue,
        'average_sale': average_sale,
    }
    return render(request, 'sales/sales_list.html', context)

@login_required
def sale_detail(request, pk):
    """View sale details"""
    sale = get_object_or_404(Sale.objects.prefetch_related('items__product'), pk=pk)
    return render(request, 'sales/sale_detail.html', {'sale': sale})

@login_required
def sale_receipt_pdf(request, pk):
    """Generate PDF receipt for a sale"""
    from shop_system.utils import render_to_pdf
    from django.http import HttpResponse
    
    sale = get_object_or_404(Sale.objects.prefetch_related('items__product'), pk=pk)
    
    context = {
        'sale': sale,
    }
    
    pdf = render_to_pdf('sales/receipt_pdf.html', context)
    if pdf:
        response = HttpResponse(pdf, content_type='application/pdf')
        filename = f"Receipt_SALE-{sale.id}.pdf"
        response['Content-Disposition'] = f'attachment; filename="{filename}"'
        return response
    return HttpResponse("Error Rendering PDF", status=400)
