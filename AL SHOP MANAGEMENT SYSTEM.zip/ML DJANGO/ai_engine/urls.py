from django.urls import path
from . import views

urlpatterns = [
    path('', views.ai_dashboard, name='ai_dashboard'),
    path('receive-data/', views.receive_data, name='ai_receive_data'),
]
