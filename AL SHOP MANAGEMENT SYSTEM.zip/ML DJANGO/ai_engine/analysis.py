import datetime
from django.db.models import Sum, Count, F, Avg
from django.utils import timezone
from sales.models import Sale, SaleItem
from inventory.models import Product
from datetime import timedelta
import math

class AIAnalyzer:
    def __init__(self):
        self.today = timezone.now().date()

    def get_sales_forecast(self, days=7):
        """
        Simple moving average forecast for the next 'days' days.
        """
        # Get last 30 days of sales
        start_date = self.today - timedelta(days=30)
        daily_sales = Sale.objects.filter(
            timestamp__date__gte=start_date
        ).extra(select={'day': 'date(timestamp)'}).values('day').annotate(
            total=Sum('total_amount')
        ).order_by('day')

        # Calculate average daily growth/trend (simplified)
        data_points = list(daily_sales)
        if not data_points:
            return []

        # Simple average for now (can be enhanced to linear regression)
        total_revenue = sum(item['total'] for item in data_points)
        avg_daily_revenue = float(total_revenue / len(data_points)) if data_points else 0

        forecast = []
        current_date = self.today
        
        # Add a small random variation or trend factor for realism in demo
        # In a real app, use ARIMA or Prophet
        for i in range(1, days + 1):
            next_date = current_date + timedelta(days=i)
            # Simple projection: Average + slight growth
            predicted_amount = avg_daily_revenue * (1 + (0.01 * i)) 
            forecast.append({
                'date': next_date,
                'predicted_amount': round(predicted_amount, 2)
            })
            
        return forecast

    def get_low_stock_predictions(self):
        """
        Predict which items will run out of stock in the next 7 days based on sales velocity.
        """
        products = Product.objects.all()
        predictions = []
        
        start_date = self.today - timedelta(days=30)
        
        for product in products:
            # Calculate daily sales velocity
            total_sold = SaleItem.objects.filter(
                product=product,
                sale__timestamp__gte=start_date
            ).aggregate(total=Sum('quantity'))['total'] or 0
            
            daily_velocity = total_sold / 30
            
            if daily_velocity > 0:
                days_left = product.stock_quantity / daily_velocity
                if days_left <= 7:
                    predictions.append({
                        'product': product.name,
                        'current_stock': product.stock_quantity,
                        'daily_sales': round(daily_velocity, 1),
                        'days_until_stockout': round(days_left, 1),
                        'status': 'Critical' if days_left < 3 else 'Warning'
                    })
                    
        return sorted(predictions, key=lambda x: x['days_until_stockout'])

    def get_product_recommendations(self):
        """
        Identify products that are often bought together (Market Basket Analysis - Simplified).
        """
        # For this demo, we'll return top selling items that could be bundled
        top_products = SaleItem.objects.values(
            'product__name'
        ).annotate(
            total_qty=Sum('quantity')
        ).order_by('-total_qty')[:5]
        
        recommendations = []
        for item in top_products:
            recommendations.append({
                'type': 'Bundle Opportunity',
                'message': f"'{item['product__name']}' is a top seller. Consider bundling it with slower moving accessories.",
                'score': 'High'
            })
            
        return recommendations

    def get_anomalies(self):
        """
        Detect unusual sales spikes or drops.
        """
        # Get yesterday's sales
        yesterday = self.today - timedelta(days=1)
        yesterday_sales = Sale.objects.filter(
            timestamp__date=yesterday
        ).aggregate(total=Sum('total_amount'))['total'] or 0
        
        # Get 30-day average
        start_date = self.today - timedelta(days=31)
        end_date = self.today - timedelta(days=1)
        avg_sales = Sale.objects.filter(
            timestamp__date__range=[start_date, end_date]
        ).aggregate(total=Sum('total_amount'))['total'] or 0
        
        avg_sales = avg_sales / 30
        
        anomalies = []
        if avg_sales > 0:
            deviation = (yesterday_sales - avg_sales) / avg_sales
            if deviation > 0.5: # 50% higher
                anomalies.append({
                    'date': yesterday,
                    'type': 'Spike',
                    'description': f"Sales yesterday were {round(deviation*100)}% higher than the 30-day average.",
                    'severity': 'Positive'
                })
            elif deviation < -0.5: # 50% lower
                anomalies.append({
                    'date': yesterday,
                    'type': 'Drop',
                    'description': f"Sales yesterday were {round(abs(deviation)*100)}% lower than the 30-day average.",
                    'severity': 'Negative'
                })
                
        return anomalies
