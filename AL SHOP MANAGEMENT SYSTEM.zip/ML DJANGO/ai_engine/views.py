from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .analysis import AIAnalyzer
from inventory.models import Product
import json
from django.http import JsonResponse, HttpResponseBadRequest
from django.views.decorators.csrf import csrf_exempt
from .models import AIFeed

@login_required
def ai_dashboard(request):
    analyzer = AIAnalyzer()
    
    # Get insights
    forecast = analyzer.get_sales_forecast(days=7)
    stock_predictions = analyzer.get_low_stock_predictions()
    recommendations = analyzer.get_product_recommendations()
    anomalies = analyzer.get_anomalies()
    
    # Prepare chart data
    forecast_dates = [item['date'].strftime('%Y-%m-%d') for item in forecast]
    forecast_values = [item['predicted_amount'] for item in forecast]
    
    # Calculate additional metrics
    total_products = Product.objects.count()
    total_insights = len(stock_predictions) + len(recommendations) + len(anomalies)
    
    context = {
        'forecast': forecast,
        'stock_predictions': stock_predictions,
        'recommendations': recommendations,
        'anomalies': anomalies,
        'forecast_dates': json.dumps(forecast_dates),
        'forecast_values': json.dumps(forecast_values),
        'total_products': total_products,
        'total_insights': total_insights,
        'fed_data': None,
    }
    # load persisted feed (if any)
    try:
        if request.user.is_authenticated:
            feed = AIFeed.objects.filter(user=request.user).first()
        else:
            # ensure session
            if not request.session.session_key:
                request.session.save()
            feed = AIFeed.objects.filter(session_key=request.session.session_key).first()
        context['fed_data'] = feed.payload if feed else {}
    except Exception:
        context['fed_data'] = {}

    return render(request, 'ai_engine/dashboard.html', context)



@csrf_exempt
def receive_data(request):
    """Receive JSON data from other pages and cache it for the AI dashboard."""
    # Determine feed storage key (per-user or per-session)
    # Determine storage record (per-user or per-session)
    if request.method == 'DELETE':
        try:
            if request.user.is_authenticated:
                AIFeed.objects.filter(user=request.user).delete()
            else:
                if request.session.session_key:
                    AIFeed.objects.filter(session_key=request.session.session_key).delete()
            return JsonResponse({'status': 'cleared'})
        except Exception:
            return JsonResponse({'status': 'error'}, status=500)

    if request.method != 'POST':
        return HttpResponseBadRequest('POST or DELETE only')

    try:
        payload = json.loads(request.body.decode('utf-8'))
    except Exception:
        return HttpResponseBadRequest('Invalid JSON')

    # Persist feed
    try:
        if request.user.is_authenticated:
            # replace any existing feed for this user
            AIFeed.objects.filter(user=request.user).delete()
            AIFeed.objects.create(user=request.user, payload=payload)
        else:
            if not request.session.session_key:
                request.session.save()
            AIFeed.objects.filter(session_key=request.session.session_key).delete()
            AIFeed.objects.create(session_key=request.session.session_key, payload=payload)
        return JsonResponse({'status': 'ok'})
    except Exception:
        return JsonResponse({'status': 'error'}, status=500)
